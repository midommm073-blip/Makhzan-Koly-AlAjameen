package com.example.inventory

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment

data class Item(val name: String, val unit: String = "قطعة", val book: Int = 0, val actual: Int = 0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { InventoryApp() }
    }
}

@Composable
fun InventoryApp() {
    val initial = listOf("فلتر 1","فلتر 2","فلتر 3","فلتر 4","فلتر 5","فلتر 6","وصلات","كبسولات","كرموز","سترو","هيبارين","بلاستر","جوانتيات","قطن","سرنجات")
    var items by remember { mutableStateOf(initial.map { Item(it) }) }
    var selected by remember { mutableStateOf(0) }

    MaterialTheme {
        Scaffold(
            topBar = { CenterAlignedTopAppBar(title = { Text("جرد مخزن كلى العجميين") }) },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(selected == 0, { selected = 0 }, icon = {}, label = { Text("الرئيسية") })
                    NavigationBarItem(selected == 1, { selected = 1 }, icon = {}, label = { Text("الأصناف") })
                    NavigationBarItem(selected == 2, { selected = 2 }, icon = {}, label = { Text("الجرد") })
                }
            }
        ) { pad ->
            when (selected) {
                0 -> Dashboard(items, Modifier.padding(pad))
                1 -> ItemList(items, Modifier.padding(pad))
                else -> CountScreen(items, onUpdate = { i, b, a ->
                    items = items.mapIndexed { idx, x -> if (idx == i) x.copy(book=b, actual=a) else x }
                }, Modifier.padding(pad))
            }
        }
    }
}

@Composable
fun Dashboard(items: List<Item>, modifier: Modifier) {
    val diff = items.sumOf { it.actual - it.book }
    Column(modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("لوحة التحكم", style = MaterialTheme.typography.headlineMedium)
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) {
            Text("إجمالي الأصناف: ${items.size}")
            Text("إجمالي العجز: ${-items.sumOf { minOf(0, it.actual-it.book) }}")
            Text("إجمالي الزيادة: ${items.sumOf { maxOf(0, it.actual-it.book) }}")
            Text("صافي الفرق: $diff")
        }}
        Text("جاهز لبدء الجرد الفعلي.")
    }
}

@Composable
fun ItemList(items: List<Item>, modifier: Modifier) {
    LazyColumn(modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(items) { x ->
            Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(x.name)
                Text(x.unit)
            }}
        }
    }
}

@Composable
fun CountScreen(items: List<Item>, onUpdate: (Int, Int, Int) -> Unit, modifier: Modifier) {
    LazyColumn(modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(items.withIndex().toList()) { (i, x) ->
            var book by remember(x.book) { mutableStateOf(x.book.toString()) }
            var actual by remember(x.actual) { mutableStateOf(x.actual.toString()) }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(x.name, style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(book, { book=it; onUpdate(i,it.toIntOrNull()?:0,actual.toIntOrNull()?:0) }, Modifier.weight(1f), label={Text("دفتري")})
                        OutlinedTextField(actual, { actual=it; onUpdate(i,book.toIntOrNull()?:0,it.toIntOrNull()?:0) }, Modifier.weight(1f), label={Text("فعلي")})
                    }
                    Text("الفرق: ${((actual.toIntOrNull()?:0) - (book.toIntOrNull()?:0))}")
                }
            }
        }
    }
}
